module.exports = async({message}) => {

    message.channel.send(`Vai uma esfiha ae? :yum: :yum: :yum:`);
    message.channel.send('https://tenor.com/view/gil-das-esfihas-galerito-esfiha-meme-brasil-gif-21194713');
}