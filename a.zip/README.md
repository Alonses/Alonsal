Alonsal é um bot multi-tarefas para o Discord
